"""
Steganography methods for the imager application.

This module provides all of the test processing operations (encode, decode)
that are called by the application. Note that this class is a subclass of Filter.
This allows us to layer this functionality on top of the Instagram-filters,
providing this functionality in one application.

Based on an original file by Dexter Kozen (dck10) and Walker White (wmw2)

Author: Chelsie Beavers cdb95 and Babafemi Badero bkb55
Date:   November 20, 2019
"""
import a6filter
#import math


class Encoder(a6filter.Filter):
    """
    A class that contains a collection of image processing methods

    This class is a subclass of Filter.  That means it inherits all of the
    methods and attributes of that class too. We do that separate the
    steganography methods from the image filter methods, making the code
    easier to read.

    Both the `encode` and `decode` methods should work with the most recent
    image in the edit history.
    """

    def encode(self, text):
        """
        Returns True if it could hide the text; False otherwise.

        This method attemps to hide the given message text in the current
        image. This method first converts the text to a byte list using the
        encode() method in string to use UTF-8 representation:

            blist = list(text.encode('utf-8'))

        This allows the encode method to support all text, including emoji.

        If the text UTF-8 encoding requires more than 999999 bytes or the
        picture does  not have enough pixels to store these bytes this method
        returns False without storing the message. However, if the number of
        bytes is both less than 1000000 and less than (# pixels - 10), then
        the encoding should succeed.  So this method uses no more than 10
        pixels to store additional encoding information.

        Parameter text: a message to hide
        Precondition: text is a string
        """
        assert type(text) == str

        current = self.getCurrent()
        blist = list(text.encode('utf-8'))
        byte_list = []
        #pos = 0
        b = len(blist)
        #print('This is b: ' + str(b))
        pos = 0
        if len(blist) >= 1000000 or len(blist) >= ((current.getHeight() * current.getWidth())-10):
            return False
        else:
            #beginning of message - this has a message (this is a message = first 2, lngth = 2nd, end = last 2)
            for i in range(5):
                new_pixel = self._encode_pixel(456, pos)
                #byte_list.append(self._encode_pixel(456, pos))
                byte_list.append(new_pixel)
                pos +=1
                #actual message

            # encode (b//1000, #)
            # encode (b%1000, #)
            for j in range(b):
                new_pixel = self._encode_pixel(blist[j], pos)
                byte_list.append(new_pixel)
                #byte_list.append(new_pixel = self._encode_pixel(blist[j], pos))
                pos +=1
            #end of messsage
            for k in range(5):
                new_pixel = self._encode_pixel(567, pos)
                byte_list.append(new_pixel)
                #byte_list.append(new_pixel = self._encode_pixel(567, pos))
                pos+=1
            # pos1 = current[6]
            # pos2 = current[7]
            # pos1 = b//1000
            # pos2 = b%1000
            # pos1 = self._encode_pixel(current[6])
            # pos2 = self._encode_pixel(current[7])
            return True

            #print(byte_list)


        # def round_down(x):
        #     x = x/10.0
        #     x = math.floor(x)
        #     x = int(x * 10)
        #     return x
        #
        # def list_num(y):
        #     num_acc = []
        #     y = str(y)
        #     for d in y:
        #         num_acc.append(int(d))
        #     return num_acc
        #
        # #if self.getHeight * self.getWidth blist:
        # if len(blist) >= 1000000 and len(blist) >= ((self.getHeight() * self.getWidth())-10):
        #     return False
        # else:
        #     for i in range(5):
        #         pix = self.getCurrent()[i]
        #         #for j in pix:
        #             #round_down(j)
        #         red,green,blue = pix
        #         new_pix = (round_down(red), round_down(green), round_down(blue))
        #         current.setPixel((i//current.getWidth()), (i%current.getHeight()), new_pix)
        #     text_len = len(blist)
        #     list_text = list_num(text_len)
        #     zero_list = [0]*(15-len(list_text))
        #     #digit_with_zero is the 15 digit list
        #     digit_with_zero = zero_list + (list_text)
        #     #print(digit_with_zero)
        #     resume_acc = 0
        #     # for each pixel, there are 5 pixels
        #     for i in range(5, 10):#len(blist)
        #         pix = self.getCurrent()[i]
        #         # for red, green, and blue in pixel
        #         #for j in pix:
        #             #round_down(j)
        #         red,green,blue = pix
        #         # we want to change last digit
        #         new_pix = (round_down(red) + digit_with_zero[resume_acc],round_down(green) + digit_with_zero[resume_acc + 1],round_down(blue) + digit_with_zero[resume_acc+ 2])
        #         current.setPixel((i//current.getWidth()), (i%current.getHeight()), new_pix)
        #         resume_acc +=3
        #
        #     #convert blist into list of digits - every number must be broken up and combied to whole list
        #     #digits for each number is it's own list. then make a list of all the lists.
        #     #combine byte list
        #     #divide by 3 to find how many pixels we nee
        #     # for every number in bytle, add each digit to r,g,b (repeat 82-99)
        #     # change starting at 11th pixel
        #
        #     #range blist +5
        #     pix_resume_acc = 10 # same thing as starting at pixel #11
        #     for ibyte in blist:
        #         list_byte = list_num(ibyte)
        #         zero_list = [0]*(3-len(list_byte))
        #         #digit_with_zero is the 3 digit list
        #         digit_with_zero = zero_list + (list_byte)
        #         pix = self.getCurrent()[pix_resume_acc]
        #         # for red, green, and blue in pixel
        #         red,green,blue = pix
        #         # we want to change last digit
        #         new_pix = (round_down(red) + digit_with_zero[0],round_down(green) + digit_with_zero[1],round_down(blue) + digit_with_zero[2])
        #         current.setPixel((i//current.getWidth()), (i%current.getHeight()), new_pix)
        #         pix_resume_acc += 1
        #
        #     return True


            #store length of the message
            # convert message to digit list
            # list at pos 0-11should have 0's in front and real numbers in last 3
            #round down digit then change # at position 2

        # You may modify anything in the above specification EXCEPT
        # The first line (Returns True...)
        # The last paragraph (If the text UTF-8 encoding...)
        # The precondition (text is a string)
        #pass    # Implement me

    def decode(self):
        """
        Returns the secret message (a string) stored in the current image.

        The message should be decoded as a list of bytes. Assuming that a list
        blist has only bytes (ints in 0.255), you can turn it into a string
        using UTF-8 with the decode method:

            text = bytes(blist).decode('utf-8')

        If no message is detected, or if there is an error in decoding the
        message, this method returns None
        """
        # get the list of bytes
        # decode the lsit of bytes
        #
        current = self.getCurrent()
         #find lenth of the image (maybe, this could be height*width)
        g = len(self.getCurrent())
        blist = []
        #print(blist)
        #print('This is the current immage: ' + str(current[6]))
        #image_num =
        pos = 0
         # the above current will be the modified
        # decoded = _decode_pixel(current)
         #this should return the original numbers
        # if current[0] == '':
        #      return ''

        # b = True
        # for i in range(5):
        #     b = b and self._decode_pixel(i) != 456
        # if b:
        #      return None
        if self._decode_pixel(1) != 456:
             return None
        if self._decode_pixel(2) != 456:
             return None
        if self._decode_pixel(3) != 456:
             return None
        if self._decode_pixel(4) != 456:
             return None
     #current[6] == '':
        #      return ''
        #if self._decode_pixel(0) != 456:
             #return None
        else:
            # for i in range(5):
            #      blist.append(self._decode_pixel(456))
            #      pos +=1

                 #actual message
            # for x in range(g-5):
            #     blist.append(self._decode_pixel(x))
            x = 5
            while self._decode_pixel(x) != 567:
                blist.append(self._decode_pixel(x))
                x +=1

            # for j in range(g):
            #      blist.append(self._decode_pixel(j))
            #      pos +=1
             #end of messsage
            # for k in range(5):
            #      blist.append(self._decode_pixel(567))
            #      pos+=1

            text = bytes(blist).decode('utf-8')
            print(text)
            return text


        # You may modify anything in the above specification EXCEPT
        # The first line (Returns the secret...)
        # The last paragraph (If no message is detected...)
        #pass    # Implement


        #returns end and add to list and pass list into text
        # use start marker - make sure first few pixel are qual to those found
        #     within marker range (makes sure there is a msessage)
        #go through all pixels and turn into bytes using decode_pixel
        #only go up to bytes for marker
        # use bytes.decode
        #end at end of message
        # we are generating blist and getting text at end
        #we do this by looping though current and adding each

        #think of decode_pixel as pixel to byte
        #pass
        #0-5
        #5-Height
        #height+5

    # HELPER METHODS
    def _decode_pixel(self, pos):
        """
        Return: the number n hidden in pixel pos of the current image.

        This function assumes that the value was a 3-digit number encoded as
        the last digit in each color channel (e.g. red, green and blue).

        Parameter pos: a pixel position
        Precondition: pos is an int with  0 <= p < image length (as a 1d list)
        """
        # This is helper. You do not have to use it. You are allowed to change it.
        # There are no restrictions on how you can change it.
        rgb = self.getCurrent()[pos]
        red   = rgb[0]
        green = rgb[1]
        blue  = rgb[2]
        return  (red % 10) * 100  +  (green % 10) * 10  +  blue % 10


    def _encode_pixel(self, byte, pos):
        """
        Return: the number n hidden in pixel pos of the current image.

        This function assumes that the value was a 3-digit number encoded as
        the last digit in each color channel (e.g. red, green and blue).

        Parameter pos: a pixel position
        Precondition: pos is an int with  0 <= p < image length (as a 1d list)
        """
    #    pos = 0
        #print('This is pos: ' + str(pos))
        rgb = self.getCurrent()[pos]
        red = rgb[0]//10*10
        x_1= byte//100
        if red + x_1 > 255:
            red = 255
        else:
            red = red + x_1
        #print(blist[pos])
        green = rgb[1]//10*10
        x_2 = (byte//10)%10
        if green + x_2 > 255:
            green = 255
        else:
            green = green + x_2
        #print(blist[pos])
        blue = rgb[2]//10*10
        x_3 = byte%10
        if blue + x_3 > 255:
            blue = 255
        else:
            blue = blue + x_3
        self.getCurrent()[pos] = (red, green, blue)
        # print(red)
        # print(green)
        # print(blue)
        #print(blist[pos])
